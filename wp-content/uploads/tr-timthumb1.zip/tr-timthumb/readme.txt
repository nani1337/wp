=== TR Timthumb ===
Contributors: pntrinh
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=332VYXNLPXE5C
Tags: timthumb,regenerate thumbnails,create thumbnail, crop image,resize image, resize, image, photo, ngoctrinh.net
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 4.3
License: GPL2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Timthumb. Use filter "tr_timthumb" params: (url,args): - url to image, args: array('w'=>100,'h'=>100,zc=>1,q=>'100') , or you can use shortcode : [tr_timthumb w="100" h="100" zc="1" q="90" class="class" alt="title"]

== Description ==

Timthumb. Use filter "tr_timthumb" params: (url,args): - url to image, args: array('w'=>100,'h'=>100,zc=>1,q=>'100') , or you can use shortcode : [tr_timthumb w="100" h="100" zc="1" q="90" class="class" alt="title"]


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload plugin folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the plugin menu in WordPress
3. use widgets , shortcode...

== Frequently Asked Questions ==

= Any question  =

please chat by skype: pntrinh



== Changelog ==

= 1.0.1 =
* upload plugin

= 1.0.2 =
* fix bug

= 1.0.3 =
* Add shortcode : tr_timthumb

= 1.0.4 =
* Add Featured reCreate Thumbnails